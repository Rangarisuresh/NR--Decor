	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy;  NR DECORS</b>
		</div>
	</div>